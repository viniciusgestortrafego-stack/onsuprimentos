<?php
// Tema de página única: o index.php contém a landing page completa.
add_action('wp_enqueue_scripts', function () {
    $uri = get_template_directory_uri();
    $ver = wp_get_theme()->get('Version');
    wp_enqueue_style('on-suprimentos', get_stylesheet_uri(), [], $ver);
    wp_enqueue_script('on-app', $uri . '/app.js', [], $ver, true);
    wp_enqueue_script('on-catalog-data', $uri . '/catalog-data.js', [], $ver, true);
    wp_enqueue_script('on-catalog', $uri . '/catalog.js', ['on-catalog-data'], $ver, true);
    wp_add_inline_script('on-catalog-data', 'window.ON_ASSET_BASE = ' . wp_json_encode($uri . '/') . ';', 'before');
});
